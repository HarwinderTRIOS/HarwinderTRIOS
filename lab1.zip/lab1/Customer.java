import java.util.ArrayList;
//Customer class containes customer name and balance of his card
// methods : addtocart add products in the list and display warning message of low balance
//displaycart method just print the list of items

public class Customer  {
	private final String cust_name;      //customer name variable
	private double balance;        //Customer's balance
	private final ArrayList<String> listOfProducts=new ArrayList();   //listOfProducts is the list of products
	
	public Customer(String name,double balance){
		this.cust_name=name;
		this.balance=balance;
	}
	
	String addToCart(Product product) {
	      if (this.balance >= Product.price){
	            listOfProducts.add(product.name);
	            this.balance=balance- Product.price;

	            if (this.balance < 5){
	                return "Warning: Low Balance";
	            }
	            else {
	            return "Success";
	            }
	        }else{
	            return "Low Balance";
	        }
		
	}
	
	void displayCart(){

		for (String listOfProduct : listOfProducts) System.out.println(listOfProduct);
	}
	

}
