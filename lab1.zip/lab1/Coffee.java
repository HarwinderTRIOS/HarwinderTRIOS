//child class coffee
//variables number of creams & sugar
//method how many coffee returns how many coffees one can buy with given amount
class Coffee extends Product{ //child class Coffee

    int numOfCream;
    int numOfSugar;
    
    public Coffee(String name, double price, int numOfCream, int numOfSugar) {
        super(name, price);
        this.numOfCream = numOfCream;
        this.numOfSugar = numOfSugar;
    }
    
    static int howManyCoffees(){  //return how many no of coffees one can buy with this given amount
       return (int) ((double) 40 /price);
    }
}