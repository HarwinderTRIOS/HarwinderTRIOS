//product class contains name and price of product
//two methods get name and price of products
public class Product{
    
    String name;
    static double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public void getName() {
        System.out.println(this.name);
    }

    public void getPrice() {
        System.out.println(this.price);
    }

}




