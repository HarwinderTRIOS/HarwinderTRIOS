
public class Donut extends Product {
	
	public Donut(String name, double price) {
        super(name, price);
    }
    static int howManyDonuts(double amount){ //return how many no of Donuts one can buy with this given amount
    	  return (int)(amount/price); 
    }
}
