// bagel is the child class
//it contains variables  toasted,creamcheese and butter 
//method howmanybagels tells that how many bagels one can buy 
 class Bagel extends Product{

	
    boolean Toasted;
    boolean CreamCheese;
    boolean butter;
    
    public Bagel(String name, double price, boolean Toasted, boolean creamCheese, boolean butter) {//constructor
        super(name, price);
        this.Toasted = Toasted;
        this.CreamCheese = creamCheese;
        this.butter = butter;
    }
   static int howManyBagels(double amount){ //return how many no of Bagels one can buy with this given amount
       return (int) (amount/price);
    }
}
