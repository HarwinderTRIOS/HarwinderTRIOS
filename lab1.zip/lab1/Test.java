
//Test Class
//it contains three objects of three child classes coffee,bagel,donut and customer class
//howmanycoffee method prints that how many coffees we can buy
//it prints the addtocart message and display list of cart items

public class Test {

	public static void main(String[] args) {
		   Coffee c = new Coffee("Coffee", 1.50, 1, 1);
	        Bagel b = new Bagel("Bagel", 2.50, true, true, false);
	        Donut d = new Donut("Donut", 2);

	        Customer c1 = new Customer("Harwinder and Amandeep", 40);
	        System.out.println(Coffee.howManyCoffees());
	        System.out.println(c1.addToCart(c));
	        System.out.println(c1.addToCart(d));
	       
	       
	       
	        c1.displayCart();
	        

	}

}
